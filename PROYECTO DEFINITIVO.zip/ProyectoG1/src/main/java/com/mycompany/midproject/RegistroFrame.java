package com.mycompany.midproject;
import java.awt.Desktop;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.MessageFormat; 
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JFileChooser;

public class RegistroFrame extends javax.swing.JFrame {
    
    String matrizRegistro[][] = new String[100][3];
    int matrizFila = 0;
    
    
    public RegistroFrame() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); 
        setTitle("Tabla de registros");
    }
    public boolean existeEnMatriz(String dni){
        for(int i=0; i < matrizFila; i++){
        if(matrizRegistro[i][1].equals(dni)){return true;}
    }
    return false;
    }
    listaClass Alist = new listaClass();
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jDialog1 = new javax.swing.JDialog();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbRegistro = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        txtDNI = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        rbSi = new javax.swing.JRadioButton();
        rbNo = new javax.swing.JRadioButton();
        txtPP = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        btnInfo = new javax.swing.JButton();
        btnBoleta = new javax.swing.JButton();
        cbMarca = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnCalcular = new javax.swing.JButton();
        btnCC = new javax.swing.JButton();
        btnLimpiar1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        lblInteres = new javax.swing.JLabel();
        lblPS = new javax.swing.JLabel();
        lblCostoTotal = new javax.swing.JLabel();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setText("DNI");

        jLabel4.setText("Precio del servicio");

        tbRegistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "DNI", "Marca", "P.Servicio", "Interes", "Costo Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbRegistro);

        btnAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/agregar-producto.png"))); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        txtDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDNIActionPerformed(evt);
            }
        });

        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre");

        jLabel2.setText("Marca");

        jLabel5.setText("Pagos por partes (intereses):");

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/borrar.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jLabel6.setText("Pagar en partes?");

        buttonGroup1.add(rbSi);
        rbSi.setText("Si");
        rbSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbSiActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbNo);
        rbNo.setText("No");
        rbNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbNoActionPerformed(evt);
            }
        });

        txtPP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPPActionPerformed(evt);
            }
        });

        jLabel7.setText("Cantidad de meses");

        btnInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/recibo.png"))); // NOI18N
        btnInfo.setText("info");
        btnInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInfoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(14, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(btnInfo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtPP, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbNo, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbSi, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 4, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbSi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbNo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(btnInfo))
        );

        btnBoleta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/factura.png"))); // NOI18N
        btnBoleta.setText("Boleta");
        btnBoleta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBoletaActionPerformed(evt);
            }
        });

        cbMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Eligir", "BMW", "Porsche", "Maserati", "Mercedes" }));
        cbMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbMarcaActionPerformed(evt);
            }
        });

        jLabel8.setText("Precio por Ser. :");

        jLabel9.setText("Interes:");

        jLabel10.setText("Costo Total:");

        btnCalcular.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/calculadora.png"))); // NOI18N
        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });

        btnCC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/nueva-cuenta.png"))); // NOI18N
        btnCC.setText("Nro ° de clientes");
        btnCC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCCActionPerformed(evt);
            }
        });

        btnLimpiar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/remover-archivo.png"))); // NOI18N
        btnLimpiar1.setText("Limpiar");
        btnLimpiar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiar1ActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/house.png"))); // NOI18N
        jButton1.setText("Menú");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel1))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel3)
                        .addComponent(txtNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                        .addComponent(txtDNI, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtPrecio, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                        .addComponent(cbMarca, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(32, 32, 32))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblInteres, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblCostoTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPS, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(58, 58, 58))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(btnCalcular)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(btnAgregar)
                .addGap(18, 18, 18)
                .addComponent(btnLimpiar1)
                .addGap(18, 18, 18)
                .addComponent(btnBoleta)
                .addGap(18, 18, 18)
                .addComponent(btnCC)
                .addGap(28, 28, 28)
                .addComponent(btnEliminar)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(lblPS, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(lblInteres, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(lblCostoTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnCalcular)
                                .addGap(37, 37, 37))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregar)
                    .addComponent(btnBoleta)
                    .addComponent(btnEliminar)
                    .addComponent(btnCC)
                    .addComponent(btnLimpiar1))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        try{
           String seleccion = cbMarca.getSelectedItem().toString();  
           String a = txtNombre.getText();
           String b = txtDNI.getText();
           ClientesClass z = new ClientesClass(a, b);
           baseDeDatos.lista.add(z);
            if(a.length()==0 || b.length()==0 || txtPrecio.getText().length()==0 || 
               seleccion.equals("Elegir") || txtPP.getText().length()==0) throw new Exception("Las casillas no deben estar vacias");
            if(existeEnMatriz(b)){
                JOptionPane.showMessageDialog(this, "El DNI " + b + " ya se encuentra registrado");return;
            }
            matrizRegistro[matrizFila][1]=b;
            matrizFila++;
            String c = lblPS.getText();
            String d = lblInteres.getText();
            String e = lblCostoTotal.getText();
            DefaultTableModel model = (DefaultTableModel)tbRegistro.getModel();
            model.addRow(new Object[]{a,b,cbMarca.getSelectedItem(),c,d,e});
            if(!Alist.listaDNI.contains(txtDNI.getText())) Alist.agregar(txtDNI.getText());
       }
       catch(Exception e){
       JOptionPane.showMessageDialog(this, e.getMessage());
       }
       
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        DefaultTableModel model = (DefaultTableModel)tbRegistro.getModel();
        int valorNumericoSeleccionado = tbRegistro.getSelectedRow();
        if(valorNumericoSeleccionado!=-1){
            model.removeRow(valorNumericoSeleccionado);
            JOptionPane.showMessageDialog(this, "La fila "+valorNumericoSeleccionado +1+" ha sido eliminada correctamente");
            File f = new File("D:/autolavado.txt");
            if(f.delete())System.out.println("archivo eliminado correctamente");
            else System.out.println("El archivo no se ha eliminado");
        }
        else JOptionPane.showMessageDialog(this, "Debes seleccionar una fila");
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        try{
            if(txtNombre.getText().length()==0) throw new Exception("El nombre no debe estar vacio");
            if(txtNombre.getText().startsWith(" ")) throw new Exception("No debe iniciar con espacios en blanco");
            char s1[] = txtNombre.getText().toCharArray();
            for(int i =0; i<s1.length;i++) if(Character.isDigit(s1[i])) throw new Exception("No se permiten digitos en el nombre");
            txtDNI.requestFocus();
        }    
        catch(Exception e){
           JOptionPane.showMessageDialog(this, e.getMessage());
           txtNombre.setText("");txtNombre.requestFocus();
        }
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDNIActionPerformed
        try{
            if(txtDNI.getText().length()> 8 || txtDNI.getText().length()< 8) throw new Exception("Coloque correctamente su DNI");
            cbMarca.requestFocus();
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this,"No se admiten letras en el DNI");
            txtDNI.setText("");txtDNI.requestFocus();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage());
            txtDNI.setText("");txtDNI.requestFocus();
        }
    }//GEN-LAST:event_txtDNIActionPerformed

    private void cbMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbMarcaActionPerformed
        txtPrecio.requestFocus();
    }//GEN-LAST:event_cbMarcaActionPerformed

    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        try{
            if(txtPrecio.getText().length()==0)throw new Exception("Coloque el precio por servicio");
            if(txtPrecio.getText().startsWith(" "))throw new Exception("No se permite inciar con espacios en blanco");
            if (Integer.parseInt(txtPrecio.getText())<0)throw new Exception("El precio no debe ser negativo");
            txtPP.requestFocus();
        }
        catch(NumberFormatException e){
        JOptionPane.showMessageDialog(this, "No se admiten letras en el precio");txtPrecio.setText("");
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(this, e.getMessage());txtPrecio.setText("");
        }
    }//GEN-LAST:event_txtPrecioActionPerformed

    private void txtPPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPPActionPerformed
        try{
            if(txtPP.getText().isEmpty()) throw new Exception("No se permite dejar la casilla en blanco");
        }
        catch(NumberFormatException e){
        JOptionPane.showMessageDialog(this, "No se admiten letras en la casilla de meses");
        txtPP.setText("");txtPP.requestFocus();
        }
        catch(Exception ex){
        JOptionPane.showMessageDialog(this, ex.getMessage());txtPP.setText("");
        }       
    }//GEN-LAST:event_txtPPActionPerformed

    private void btnBoletaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBoletaActionPerformed
        try{
            JFileChooser selector = new JFileChooser();
            selector.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int guardar = selector.showSaveDialog(this);
            if(guardar==1) return;
            int valorNum = tbRegistro.getSelectedRow();
            if(valorNum == -1) throw new Exception("Debe seleccionar una fila");
            String a = tbRegistro.getValueAt(valorNum, 0).toString();
            String b = tbRegistro.getValueAt(valorNum, 1).toString();
            String c = tbRegistro.getValueAt(valorNum, 2).toString();
            String d = tbRegistro.getValueAt(valorNum, 3).toString();
            String e = tbRegistro.getValueAt(valorNum, 4).toString();
            String f = tbRegistro.getValueAt(valorNum, 5).toString();
            File archivo = selector.getSelectedFile();
            if(archivo.getName().matches(".*[#$<>*+%-/_.;:,].*"))throw new Exception("No Caracteres Especiales");
            FileWriter fw = new FileWriter(archivo);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.print(MessageFormat.format("""
            ......BOLETA......
            Cliente: {0}
            DNI: {1}
            Marca del Vehiculo: {2}
            Precio del Servicio: {3}
            Interes: {4}
            ...............
            Costo Total: {5}
            ...............
            MUCHAS GRACIAS 
            POR ESCOGERNOS!
            """, a,b,c,d,e,f));
            cargaFrame app = new cargaFrame();
            app.setVisible(true);
            Timer timy = new Timer();
            timy.schedule(new TimerTask() {
                @Override
                public void run() {
                    try{
                        app.dispose(); // cierra la ventana pero la ventana sigue ejecutandose por el bucle generado por el graphics, por eso salir el error de null
                        pw.close();
                        Desktop.getDesktop().open(archivo);
                    }
                    catch(IOException ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                    }
                    timy.cancel();
                }
            }, 3000); // 3 segundos
        } 
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_btnBoletaActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        try{
            if(txtPrecio.getText().isEmpty() || txtPP.getText().isEmpty())throw new Exception("No se permiten espacios en blanco en las casillas");
            int precioI = Integer.parseInt(txtPrecio.getText());
            if(precioI <= 0) throw new Exception("El precio no puede ser negativo o cero");
            if(!rbNo.isSelected() && !rbSi.isSelected()){
                JOptionPane.showMessageDialog(this, "Debe seleccionar una casilla");
                return;
            }
            recursividadClass app = new recursividadClass();
            if(rbSi.isSelected()){
                double interes = app.recursividad(Integer.parseInt(txtPP.getText()), precioI);
                lblPS.setText("S/. " + txtPrecio.getText());
                lblInteres.setText("S/. " + interes);
                lblCostoTotal.setText("S/. " + (precioI+interes));
            }
            if(rbNo.isSelected()){
                lblPS.setText("S/. " + txtPrecio.getText());
                lblInteres.setText("S/. 0");
                lblCostoTotal.setText("S/. " + txtPrecio.getText());
            }
        }
        catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this, "Formato no valido, intente nuevamente");
            txtPrecio.setText("");txtPP.setText("");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
            txtPrecio.setText("");txtPP.setText("");
        }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void rbNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbNoActionPerformed
           txtPP.setEnabled(false);txtPP.setText("0");
    }//GEN-LAST:event_rbNoActionPerformed

    private void rbSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbSiActionPerformed
        txtPP.setEnabled(true);txtPP.setText("");
    }//GEN-LAST:event_rbSiActionPerformed

    private void btnInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInfoActionPerformed
        JOptionPane.showMessageDialog(this, """
            Según los meses que elijas, 
            dependerá tu nivel de interés.
            """);
    }//GEN-LAST:event_btnInfoActionPerformed

    private void btnCCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCCActionPerformed
        JOptionPane.showMessageDialog(this,"Cantidad total de clientes: " + Alist.cantidadClientes());
    }//GEN-LAST:event_btnCCActionPerformed

    private void btnLimpiar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiar1ActionPerformed
        txtNombre.setText("");txtDNI.setText("");txtPrecio.setText("");txtPP.setText("");
        lblPS.setText("");lblInteres.setText("");lblCostoTotal.setText("");
        cbMarca.setSelectedIndex(0);buttonGroup1.clearSelection();txtNombre.requestFocus();
    }//GEN-LAST:event_btnLimpiar1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MenuFrame menu = new MenuFrame();
        menu.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new RegistroFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBoleta;
    private javax.swing.JButton btnCC;
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInfo;
    private javax.swing.JButton btnLimpiar1;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbMarca;
    private javax.swing.JButton jButton1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCostoTotal;
    private javax.swing.JLabel lblInteres;
    private javax.swing.JLabel lblPS;
    private javax.swing.JRadioButton rbNo;
    private javax.swing.JRadioButton rbSi;
    private javax.swing.JTable tbRegistro;
    private javax.swing.JTextField txtDNI;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPP;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
