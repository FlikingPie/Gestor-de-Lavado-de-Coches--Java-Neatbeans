
package com.mycompany.midproject;

import java.util.ArrayList;

public class ClientesClass {
    private String nombre;
    private String dni;
    public ClientesClass(String nombre, String dni){
    this.nombre = nombre;
    this.dni = dni;
    }
    //metodo getter
    public String getNombre(){return nombre;}
    public String getDni(){return dni;}
}
