/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.midproject;

/**
 *
 * @author CLIENTE
 */
public class MidProject {
    public static void main(String[] args) {
        new UsuarioFrame().setVisible(true);
    }
}
