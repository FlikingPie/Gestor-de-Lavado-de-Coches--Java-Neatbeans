
package com.mycompany.midproject;

public class recursividadClass {
     double recursividad(int mes, int precio){
     if (mes <=0) return 0;
     double interes = mes * 0.05;
     return (precio * interes) + recursividad(mes-1, precio);
     }
}