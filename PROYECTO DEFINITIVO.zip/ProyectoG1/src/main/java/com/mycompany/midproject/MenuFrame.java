package com.mycompany.midproject;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.xml.catalog.Catalog;

public class MenuFrame extends javax.swing.JFrame {
    Color mColorFondo= new Color(24,127,220);
    File f = new File("D:\\ProyectosJava\\ProyectoG1\\src\\main\\java\\com\\mycompany\\midproject\\lavado.jpg");
    BufferedImage bi;
    
    private String logo_sistema="/Icons/house.png";
    private String logo_clientes="/Icons/nueva-cuenta.png";
    private String logo_salir="/Icons/cerrar-sesion.png";
    private String logo_ayuda="/Icons/soporte-tecnico.png";    
    private String logo_vehiculos="/Icons/carro.png";
    
    public MenuFrame() {
        initComponents();
        this.getContentPane().setBackground(Color.cyan);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cuadro del menu");
        setSize(460, 600);
        try{
        bi = ImageIO.read(f);
        JPanel fondo = new JPanel(){
        @Override 
        protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(bi, 0, 0, getWidth(), getHeight(), this);
        }
        };
        fondo.setLayout(new BorderLayout());
        setContentPane(fondo);
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
        
        mbSistema.setIcon(getIcono(logo_sistema));
        mbSistema.setOpaque(true);
        mbSistema.setBackground(mColorFondo);
        mbSistema.setForeground(Color.white);
        
        mbClientes.setOpaque(true);
        mbClientes.setBackground(mColorFondo);
        mbClientes.setForeground(Color.white);
        mbClientes.setIcon(getIcono(logo_clientes));
        
        mbAyuda.setOpaque(true);
        mbAyuda.setBackground(mColorFondo);
        mbAyuda.setForeground(Color.white);
        mbAyuda.setIcon(getIcono(logo_ayuda));
        
        mbSalir.setOpaque(true);
        mbSalir.setBackground(mColorFondo);
        mbSalir.setForeground(Color.white);
        mbSalir.setIcon(getIcono(logo_salir));
        
        mbVehiculos.setOpaque(true);
        mbVehiculos.setBackground(mColorFondo);
        mbVehiculos.setForeground(Color.white);
        mbVehiculos.setIcon(getIcono(logo_vehiculos));
        
        
        
        
            
    }   
    private Icon getIcono(String ruta){
        return new ImageIcon(new ImageIcon(getClass().getResource(ruta)).getImage().getScaledInstance(30, 30, 0));
    }
    
 
    
    @SuppressWarnings("unchecked")
    Graphics g;
    int X;
    Timer timy= new Timer();
    int c=0;
    TimerTask tarea= new TimerTask() {
        @Override
        public void run() {
            //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            
            switch(c){
            case 0:
            g = Label.getGraphics();
            g.setColor(new Color(0, 255, 255)); 
            g.fillRect(0, 0, Label.getWidth(), Label.getHeight());
            X += 10;
            if(X > Label.getWidth()){
                X = -150;
            }

            g.setColor(Color.red);
            g.fillRect(X, 390, 105, 30);   

            g.setColor(Color.black);
            g.fillOval(X + 5, 415, 35, 35);    

            g.setColor(Color.white);
            g.fillOval(X + 12, 423, 18, 18);

            g.setColor(Color.black);
            g.fillOval(X + 55, 415, 35, 35);   

            g.setColor(Color.white);
            g.fillOval(X + 62, 423, 18, 18);

            g.setColor(Color.red);
            g.fillOval(X + 25, 365, 55, 35);   

            g.setColor(Color.cyan);
            g.fillRect(X + 32, 372, 15, 15);   

            g.setColor(Color.cyan);
            g.fillRect(X + 55, 372, 15, 15);   

            g.setColor(Color.black);
            g.drawRect(X + 32, 372, 15, 15);
            g.drawRect(X + 55, 372, 15, 15);

            break;
              
            case 1:
            g.setColor(Color.black);
            c = 1;
           }
                                        
        }
       
    };
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Label = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        mbSistema = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        mbClientes = new javax.swing.JMenu();
        btnMostrar = new javax.swing.JMenuItem();
        mbAyuda = new javax.swing.JMenu();
        btnAbrir = new javax.swing.JMenuItem();
        mbVehiculos = new javax.swing.JMenu();
        itemVehiculos = new javax.swing.JMenuItem();
        mbSalir = new javax.swing.JMenu();
        itemSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        Label.setBackground(new java.awt.Color(51, 255, 255));

        mbSistema.setText("Sistema");
        mbSistema.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mbSistemaActionPerformed(evt);
            }
        });

        jMenuItem1.setText("Abrir");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        mbSistema.add(jMenuItem1);

        jMenuBar1.add(mbSistema);

        mbClientes.setText("Clientes");

        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });
        mbClientes.add(btnMostrar);

        jMenuBar1.add(mbClientes);

        mbAyuda.setText("Ayuda");

        btnAbrir.setText("Abrir");
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        mbAyuda.add(btnAbrir);

        jMenuBar1.add(mbAyuda);

        mbVehiculos.setText("Vehiculos");

        itemVehiculos.setText("Ver Vehiculos");
        itemVehiculos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemVehiculosActionPerformed(evt);
            }
        });
        mbVehiculos.add(itemVehiculos);

        jMenuBar1.add(mbVehiculos);

        mbSalir.setText("Salir");

        itemSalir.setText("Salir del sistema");
        itemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSalirActionPerformed(evt);
            }
        });
        mbSalir.add(itemSalir);

        jMenuBar1.add(mbSalir);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Label, javax.swing.GroupLayout.DEFAULT_SIZE, 802, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Label, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mbSistemaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mbSistemaActionPerformed

    }//GEN-LAST:event_mbSistemaActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        RegistroFrame app = new  RegistroFrame();
        app.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
          String mensaje = "<html><body width='300'>" +
        "<h3>¿Cómo funciona el sistema?</h3>" +
        "• Completa los datos del cliente: Nombre, DNI, Marca y Precio del servicio.<br><br>" +
        "• Si el cliente pagará en partes, selecciona “Sí” y escribe la cantidad de meses.<br><br>" +
        "• Presiona el botón <b>Calcular</b> para obtener el interés y el costo total.<br><br>" +
        "• Con <b>Agregar</b> se envía la información a la tabla principal.<br><br>" +
        "• Con <b>Boleta</b> generas el comprobante de pago.<br><br>" +
        //"• <b>Total de clientes</b> muestra cuántos registros hay en la tabla.<br><br>" +
        "• <b>Eliminar</b> borra la fila seleccionada.<br><br>" +
        "</body></html>";
        JOptionPane.showMessageDialog(this, mensaje, "Soporte del sistema", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        ClientesModelFrame app = new ClientesModelFrame();
        app.setVisible(true);
        
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened

timy.scheduleAtFixedRate(tarea, 0, 50);


    }//GEN-LAST:event_formWindowOpened

    private void itemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_itemSalirActionPerformed

    private void itemVehiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemVehiculosActionPerformed
        Vehiculos ventana= new Vehiculos();
        ventana.setVisible(true);
    }//GEN-LAST:event_itemVehiculosActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label;
    private javax.swing.JMenuItem btnAbrir;
    private javax.swing.JMenuItem btnMostrar;
    private javax.swing.JMenuItem itemSalir;
    private javax.swing.JMenuItem itemVehiculos;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenu mbAyuda;
    private javax.swing.JMenu mbClientes;
    private javax.swing.JMenu mbSalir;
    private javax.swing.JMenu mbSistema;
    private javax.swing.JMenu mbVehiculos;
    // End of variables declaration//GEN-END:variables
}
