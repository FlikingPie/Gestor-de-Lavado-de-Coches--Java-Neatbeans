
package com.mycompany.midproject;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Timer;
import java.util.TimerTask;

public class cargaFrame extends javax.swing.JFrame {
    

    public cargaFrame() {
        initComponents();
        setTitle("Frame de carga");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        labell = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 426, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );

        labell.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(153, 153, 153)
                        .addComponent(labell, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(labell, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
Graphics g;
Timer timy = new Timer();
int control = 0;
TimerTask tarea = new TimerTask() { // instantacion
        @Override
        public void run() {
            g = panel.getGraphics();
            switch(control){
                case 0 -> {
                    {
                        int []a = {50,150,150,50};
                        int []b = {50,50,100,100};
                        g.setColor(Color.green);
                        g.fillPolygon(a, b, 4);
                        control = 1;
                    } 
                }
                case 1 -> {
                    {
                        int []a = {50,250,250,50};
                        int []b = {50,50,100,100};
                        g.setColor(Color.GREEN);
                        g.fillPolygon(a, b, 4);
                        control = 2;
                    } 
                }
                case 2 -> {
                    {
                        int []a = {50,350,350,100};
                        int []b = {50,50,100,100};
                        g.setColor(Color.green);
                        g.fillPolygon(a, b, 4);
                        control = 3;
                    }
                }
                case 3 -> {
                    g.clearRect(50, 50, 350, 100);
                    control = 0;
                }
            }
        }
    };
Timer timy2 = new Timer();
int control2 = 0;
TimerTask tarea2 = new TimerTask() {
        @Override
        public void run() {
            switch (control2) {
                case 0 -> {
                    {
                        labell.setText("Generando boleta.");
                        control2 = 1;
                    }
            
                }
                case 1 -> {
                    {
                        labell.setText("Generando boleta..");
                        control2 = 2;
                    }
           
                }
                case 2 -> {
                    {
                        labell.setText("Generando boleta...");
                        control2 = 3;
                    }
           
                }
                case 3 -> {
                    {
                        labell.setText("Generando boleta");
                        control2 = 0;
                    }
          
                }
            }
        }
    };
    private void formMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseMoved
    //non c’è niente, non so come cancellare questo metodo
    }//GEN-LAST:event_formMouseMoved

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            
            timy.scheduleAtFixedRate(tarea, 0, 500);
            timy2.scheduleAtFixedRate(tarea2, 0, 250);
        } catch (Exception e) {
            System.out.println("Mira como evado el error!!!");
        }
    }//GEN-LAST:event_formWindowOpened
// para evitar el error del "NullPointerException"
@Override
public void dispose() {
    try {
        timy.cancel();
        timy2.cancel();
    } catch (Exception e) {}
    super.dispose();
}
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new cargaFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel labell;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
}
