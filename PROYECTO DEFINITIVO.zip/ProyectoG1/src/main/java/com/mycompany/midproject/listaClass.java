
package com.mycompany.midproject;

import java.util.List;
import java.util.ArrayList;

public class listaClass {
    public List<String> listaDNI= new ArrayList<>();
    public void agregar(String var1) {
        listaDNI.add(var1);
    }
    public int cantidadClientes(){
        return listaDNI.size();
    }
}
