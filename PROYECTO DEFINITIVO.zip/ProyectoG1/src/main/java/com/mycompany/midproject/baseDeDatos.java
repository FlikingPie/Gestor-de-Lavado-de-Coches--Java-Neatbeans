
package com.mycompany.midproject;

import java.util.ArrayList;

public class baseDeDatos {
    public static ArrayList<ClientesClass>lista= new ArrayList<>();
}
